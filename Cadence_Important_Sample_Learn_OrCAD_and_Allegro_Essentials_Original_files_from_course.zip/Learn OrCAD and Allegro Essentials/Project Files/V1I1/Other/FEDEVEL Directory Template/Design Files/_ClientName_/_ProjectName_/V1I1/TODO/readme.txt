Here describe all the things which have to be improved or done in the next revision.

Schematic:


PCB:


Production:


Firmware: