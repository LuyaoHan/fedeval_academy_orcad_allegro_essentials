This directory should be backed up.
Keep here all the files you create and you are working on.