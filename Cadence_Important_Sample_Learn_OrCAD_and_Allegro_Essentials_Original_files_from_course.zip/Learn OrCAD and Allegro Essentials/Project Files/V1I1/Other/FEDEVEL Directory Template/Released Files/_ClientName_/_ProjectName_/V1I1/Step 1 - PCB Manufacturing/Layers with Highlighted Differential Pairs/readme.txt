Highlight differential pairs and Take screenshots of each layer. Examples of naming screenshots:

DIFF100-L1.jpg
DIFF100-L3.jpg
DIFF90-L1.jpg
...

Why? If manufacturer can not find a particular DIFF pair on one of the layers, they will contact you. 
By providing them these screenshots, they can check it by themselves.
