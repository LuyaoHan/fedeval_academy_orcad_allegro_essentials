All the files needed for CPLD, EEPROMs, uController, BIOS, ...

Start file name with component designator - the one where the file needs to be stored e.g:
U5 - AMI BIOS 0ABVQ018
U15 - Ethernet EEPROM 82574 