Place following files here:

3D board step file
3D pdf

Be aware (especially for confidential projects) what everything is included in the 3D PDF. By default, some 3D PDF documents may include information which you may not want to share e.g. net names.