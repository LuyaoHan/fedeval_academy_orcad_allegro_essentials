Place here zip file of source files, e.g copy and pack here directory from:
Design Files\_ClientName_\_ProjectName_\V1I1\

For Altium: Before creating the zip files, be sure that the NotFitted project parameter is not blank (if this parameter is used).